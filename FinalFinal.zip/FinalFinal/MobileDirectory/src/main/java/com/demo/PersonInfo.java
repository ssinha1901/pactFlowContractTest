package com.demo;

import org.springframework.context.ApplicationContext;

public class PersonInfo {
    String Name ;
    Integer Age ;
    String City ;


    public PersonInfo(String Name, Integer age, String city) {
        this.Name = Name;
        this.Age = age;
        City = city;

    }
    public PersonInfo() {

    }


    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public Integer getAge() {
        return Age;
    }

    public void setAge(Integer age) {
        Age = age;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

}
